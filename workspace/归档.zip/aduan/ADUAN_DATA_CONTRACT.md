# ADUAN Data Contract

## A. 服务商利润台账（核心）

Required fields:
- date
- channel (胡/葛)
- order_id
- model (中介/自注册)
- revenue
- cost_registration
- cost_proxy_registration
- cost_legal_person
- cost_other
- net_profit_raw
- principal_ours_recovered
- principal_channel_recovered
- net_profit_distributable
- profit_ours
- profit_channel
- cash_in
- cash_out
- status

Base formula:
- net_profit_distributable = revenue - (cost_registration + cost_proxy_registration + cost_legal_person + cost_other)

### Channel 胡 Settlement Waterfall

1) Recover our principal: 10000
2) Recover channel principal: 5000
3) Remaining distributable net profit split 55% (ours) / 45% (channel)

ceo_aduan report must include:
- unrecovered_ours_principal
- unrecovered_channel_principal
- current_distributable_profit
- recognized_profit_ours

### Channel 葛 Settlement

- Upfront cost by us: 5000 + 10000
- 100% net profit belongs to us
- Track ROI and payback period separately

## B. 小程序增长日报

Required fields:
- date
- dau
- new_users
- retention_d1
- retention_d7
- pay_users
- revenue

## C. 小红书漏斗日报（双业务）

Required fields:
- date
- biz_unit (小程序/服务商)
- exposure
- inquiry
- wechat_added
- deals
- spend

## D. 跨代理会诊回传协议（aduan_signal_v1）

适用对象：`finance`、`xiaoguan`、`xiaodong`、`xiaodong_crossborder_scout`。
当阿段通过 `sessions_spawn` 发起会诊时，子代理必须按如下 JSON 返回，不得只给自然语言段落。

### Required envelope fields

- schema_version (fixed: `aduan_signal_v1`)
- source_agent (`finance` | `xiaoguan` | `xiaodong` | `xiaodong_crossborder_scout`)
- as_of (ISO timestamp, example: `2026-03-07T09:00:00+08:00`)
- window (`24h` | `7d` | custom)
- confidence (`high` | `medium` | `low`)
- headline (one-line summary)
- data_quality.missing_fields (string array)
- data_quality.notes (string array)
- kpis (array of `{key, value, unit, baseline?, delta?}`)
- risks (array of `{level, item, trigger, impact}`)
- actions_24h (array of `{owner, action, metric, deadline}`)
- actions_7d (array of `{owner, action, metric, deadline}`)

### Agent-specific KPI keys

- finance:
  - `net_profit`
  - `net_cashflow`
  - `payback_days`
  - `unrecovered_ours_principal`
  - `unrecovered_channel_principal`
- xiaoguan:
  - `leads_new`
  - `followup_24h_rate`
  - `conversion_rate`
  - `overdue_tasks`
- xiaodong:
  - `exposure`
  - `inquiry`
  - `wechat_added`
  - `deals`
  - `spend`
  - `cpa`

### xiaodong_crossborder_scout payload rules

当 `source_agent=xiaodong_crossborder_scout` 时，仍使用 `aduan_signal_v1` envelope，但 `kpis` 可替换为跨境雷达信号字段，不强制套用 finance/xiaoguan/xiaodong 的 KPI 模板。

建议优先包含：

- `signal_type`
- `executive_summary`
- `key_signals`
- `risks`
- `opportunities`
- `recommendations.24h`
- `recommendations.7d`
- `missing_fields`
- `assumptions`
- `sources`
- `impact_summary`

额外要求：

- `source_agent` 必须固定为 `xiaodong_crossborder_scout`
- `headline` 必须能概括本次跨境信号的核心变化
- `data_quality.notes` 中需明确是否为实时验证、二手汇总、或基于行业规律的推断
- 若为推断型结论，必须显式给出 `assumptions`
- `sources` 至少 2 条；若不足 2 条，必须降为 `confidence=low`
- 若涉及归档动作，归档目录与写入口径以 `xiaodong_crossborder_scout` workspace 定义为准

### Validation rules

- Missing required fields => mark `confidence=low` and list in `data_quality.missing_fields`
- For `finance` / `xiaoguan` / `xiaodong`, any KPI without unit must provide explicit `"unit": "count"` fallback
- For `xiaodong_crossborder_scout`, `kpis` may be empty if the signal is better represented by structured radar fields
- If estimates are used, append `"(estimated)"` in `data_quality.notes`
- Output must be valid JSON block for machine merge

## KPI Priority

Primary KPI panel must prioritize:
1) cashflow and profit
2) settlement recovery speed
3) conversion efficiency

## Data Quality Rules

If any required field is missing:
- list missing fields explicitly
- mark confidence as low
- explain decision impact
- provide temporary assumptions separately
