# ceo_aduan Cron Setup

Run these commands inside container after `FEISHU_ADUAN_APP_ID/SECRET` are configured and Feishu `aduan` account probe is healthy.

Replace `<FEISHU_USER_OPEN_ID>` with your target Feishu user id.

## Daily business brief (09:30 Asia/Shanghai)

```bash
docker exec -i openclaw-kentclaw openclaw cron add \
  --agent aduan \
  --name "ceo_aduan每日经营快报" \
  --cron "30 9 * * *" \
  --tz "Asia/Shanghai" \
  --session isolated \
  --announce \
  --channel feishu \
  --account aduan \
  --to "<FEISHU_USER_OPEN_ID>" \
  --message "输出 ceo_aduan_report_v2：经营总览、关键风险与红线、Top3决策卡、任务闭环、创始人修炼面板（今日减法/不做清单/节奏修复动作）。"
```

## Weekly review (Monday 10:00 Asia/Shanghai)

```bash
docker exec -i openclaw-kentclaw openclaw cron add \
  --agent aduan \
  --name "ceo_aduan每周经营复盘" \
  --cron "0 10 * * 1" \
  --tz "Asia/Shanghai" \
  --session isolated \
  --announce \
  --channel feishu \
  --account aduan \
  --to "<FEISHU_USER_OPEN_ID>" \
  --message "输出每周复盘（非股票）：上周经营结果、本周优先级、最大风险、最大机会、回本阻塞点、任务闭环进展、创始人本周修炼重点。"
```

## Verify

```bash
docker exec -i openclaw-kentclaw openclaw cron list
```
