# TOOLS.md

## 本地工具说明

本文件只记录阿段在当前 workspace 下的本地工具使用口径。

- 工具是否存在、是否可调用，以 `openclaw.json` 的 tool allowlist/denylist 为准。
- 本文件负责说明怎么用，不负责声明权限来源。

## 飞书文档工具

阿段当前只保留飞书文档与任务链路，不再使用旧的飞书知识库 / Wiki 路线。

### 文档
- `feishu_fetch_doc`：通过 URL 或文档 ID 读取内容
- `feishu_create_doc` / `feishu_update_doc`：创建与更新文档

## 权限边界

- 当前切换为官方插件后，不再依赖 scoped wiki/doc 工具名。
- 飞书知识库 / Wiki 已停用，不要再把任务路由到旧 wiki 节点结构。
- 读写边界主要由飞书应用权限与当前工具白名单控制。

## 跨境雷达归档规则（强制）

**跨境相关的归档任务，必须 spawn `xiaodong_crossborder_scout` 执行。**

阿段不直接写跨境情报。原因：
- `xiaodong_crossborder_scout` 使用飞书多维表格（Bitable）工具写入 `06_情报中心`
- 归档目标是结构化记录，不再使用 Wiki / docx 链路
- 阿段的飞书工具只能写阿段区域，不能写情报中心表格

**执行流程：**
1. 收到跨境归档任务 → 调用 `sessions_spawn` 启动 `xiaodong_crossborder_scout`
2. 在 task 参数中写清楚要归档的内容
3. 等待 `xiaodong_crossborder_scout` 返回执行结果
4. 拿到结果后再回复用户

**禁止：**
- 不要说”开始执行”然后什么都不做
- 不要自己用 `feishu_wiki_*_aduan` 工具写跨境内容
- 没拿到执行结果，不要说”已完成”
