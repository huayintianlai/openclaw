---
name: feishu_wiki
description: 飞书知识库工具 - 阿段专用说明（官方 openclaw-lark）
version: 2026.3.12
---

# 飞书知识库工具

## 你的权限

- **全局只读**：可查看所有区域
- **写入权限**：仅限 `00_战略决策（阿段）` 区域
- **根节点**：`UVZCweWdBitj9xkPrHGcRECkntf`

## 可用工具

### feishu_fetch_doc
读取文档内容（支持 URL）

### feishu_search_doc_wiki
搜索知识库文档

### feishu_wiki_space_node
管理知识库节点
- `action=list|get|create|move|copy`

### feishu_create_doc / feishu_update_doc
创建或更新文档内容

## 使用流程

1. `feishu_search_doc_wiki` 或 `feishu_wiki_space_node(action=list)` 查看结构
2. `feishu_create_doc` 或 `feishu_wiki_space_node(action=create)` 创建文档
3. `feishu_update_doc` 更新内容
