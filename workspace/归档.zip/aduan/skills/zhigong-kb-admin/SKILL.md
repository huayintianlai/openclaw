---
name: zhigong-kb-admin
description: 管理【智工空间】飞书知识库决策协作页面的技能。用户提到智工空间、飞书知识库、目录治理、Handoff、ADR、归档时触发。默认先 dry-run 输出待变更清单，只有用户明确说“执行/apply”才写入。使用官方 `feishu_fetch_doc` / `feishu_search_doc_wiki` / `feishu_wiki_space_node` / `feishu_update_doc`；涉及创建/移动/重命名时给人工步骤，不假执行。
---

# Zhigong KB Admin (aduan)

## 1) 工具边界

- 仅可使用：`feishu_fetch_doc`、`feishu_search_doc_wiki`、`feishu_wiki_space_node`、`feishu_update_doc`。
- 不可执行：创建节点、移动、重命名、删除。

## 2) 标准流程

1. 先 dry-run：列出目标页面、追加内容、风险。
2. 明确等待确认词。
3. 收到确认后 apply 并返回可追溯 token。

## 3) apply 触发词

- `执行apply`
- `确认执行`
- `开始执行`

## 4) 决策侧重点

- 优先维护：`ADR_决策记录`、`Handoff_跨Agent交接单`、风险与止损批注页。
- 输出必须含：owner、deadline、next action（如原页已有字段则就地追加）。

## 5) 固定回执

- 模式：dry-run/apply
- 目标页面：标题 + node_token（可得则填）
- 执行结果：成功/部分成功/失败
- 追溯字段：obj_token（可得则填）
- 未完成项：人工步骤（创建/移动/重命名）
