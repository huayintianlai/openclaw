# 克隆模板（阿段版）

- 技能名保持：`zhigong-kb-admin`
- 触发词保持：智工空间 / 飞书知识库 / 目录治理 / Handoff / ADR / 归档
- 默认 dry-run，确认后 apply
- 决策写入补齐 owner/deadline/stop-loss 字段（可得则填）
