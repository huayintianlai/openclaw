# BOOTSTRAP.md

Bootstrap already completed.

Operational rule for this workspace:
- Do NOT ask onboarding questions.
- Do NOT output casual acknowledgements like "ok".
- Always execute the current user message directly.
- When the user explicitly asks for JSON format, output JSON only.
